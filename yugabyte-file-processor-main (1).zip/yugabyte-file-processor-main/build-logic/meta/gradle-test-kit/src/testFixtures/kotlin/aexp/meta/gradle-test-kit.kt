package aexp.meta

/**
 * The version of the plugin under test, e.g. "1.0.0-SNAPSHOT"
 */
fun pluginUnderTestVersion(): String = System.getProperty("pluginUnderTestVersion")

// read the output produced by the Test task config in the `gradle-test-kit` plugin
fun pluginUnderTestMavenRepo(): String = System.getProperty("pluginUnderTestMavenRepo")
