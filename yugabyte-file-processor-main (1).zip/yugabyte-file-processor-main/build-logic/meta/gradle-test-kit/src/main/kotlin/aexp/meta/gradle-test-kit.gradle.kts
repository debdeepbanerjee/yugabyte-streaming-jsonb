package aexp.meta

import org.gradle.api.plugins.JavaPlugin.TEST_IMPLEMENTATION_CONFIGURATION_NAME
import org.gradle.kotlin.dsl.support.uppercaseFirstChar

plugins {
    kotlin("jvm")
    `maven-publish`
}

dependencies {
    testImplementation(gradleTestKit())
    // have to use strings here because we are in the meta project, so we can't use the normal syntax sugar
    testImplementation(testFixtures("build-logic-meta-gradle-test-kit:build-logic-meta-gradle-test-kit"))
}

/*
 * This plugin replaces the need for `withPluginClasspath` in tests.
 *
 * If you are using GradleRunner to run builds, you can:
 * - apply this plugin to the project with the plugin under test AND all of is transitive *source* dependencies
 * - remove the `withPluginClasspath()` call
 * - Add `${pluginUnderTestMavenRepo()}` to the `pluginManagement` block inside the project created in the test method.
 * - Add `version("${pluginUnderTestVersion()}")` to any plugin that is a source dependency of the project created inside the test.
 *
 * This will publish all the source dependencies of the plugin under test transitively to a local maven repo, and
 * include the maven repo configuration needed to load those plugins in the test project.
 */
val outgoingConfigurationNameForMavenReposForTesting = "outgoingLocalMavenRepoForTesting"
val incomingConfigurationNameForMavenReposForTesting = "incomingLocalMavenRepoForTesting"
val localMavenRepoType = "local-maven-repo"

// publish each transitive subproject to a local maven repo
val localMavenRepoForTestingPlugin: Provider<Directory> = layout.buildDirectory.dir("plugin-under-test-maven-repo")
val mavenRepoName = "LocalMavenRepoForTestingPlugin"
publishing {
    repositories {
        maven {
            name = mavenRepoName
            url = localMavenRepoForTestingPlugin.get().asFile.absoluteFile.toURI()
        }
    }
}

publishing.publications.withType<MavenPublication>().configureEach {
    // "pluginMaven" is created by `maven-publish`
    // see https://github.com/gradle/gradle/blob/968dde9b832ac7f8f0c90dfee767f2e60a3c203a/subprojects/plugin-development/src/main/java/org/gradle/plugin/devel/plugins/MavenPluginPublishPlugin.java#L76-L80
    if (name == "pluginMaven") {
        groupId = project.group.toString()
        artifactId = project.name
        // Gradle needs to know what versions to put into the published metadata.
        // See https://docs.gradle.org/current/userguide/publishing_maven.html#publishing_maven:resolved_dependencies
        versionMapping {
            usage("java-api") {
                fromResolutionOf("runtimeClasspath")
            }
            usage("java-runtime") {
                fromResolutionResult()
            }
        }
    }
}

// publish task doesn't declare the output directory as an "output", but in our case we need the output to be tracked, so that the task is rerun if they directory is deleted.
tasks.withType<PublishToMavenRepository>().configureEach {
    val publishToMavenRepositoryTask = this
    if (publishToMavenRepositoryTask.name.contains(mavenRepoName)) {
        outputs.dir(localMavenRepoForTestingPlugin)
    }
}

tasks.withType<Test>().configureEach {
    // make sure we publish the plugin before the tests run
    dependsOn("publishAllPublicationsTo${mavenRepoName.uppercaseFirstChar()}Repository")
    // make sure all the publications are published for the transitive deps
    dependsOn(incomingConfigurationForMavenReposForTesting)

    val resolvedConfiguration = incomingConfigurationForMavenReposForTesting.get().resolvedConfiguration
    resolvedConfiguration.rethrowFailure()

    val transitiveDeps = mutableSetOf<ResolvedDependency>()
    resolvedConfiguration
        .firstLevelModuleDependencies
        .flatMapTo(transitiveDeps) { it.allTransitiveDependencies() }
    // "inject" info about the plugins into the tests.
    // this will be read by the test, so it can load the plugin from the local maven repo
    // see `pluginUnderTestMavenRepo()` and `pluginUnderTestVersion()`
    systemProperties["pluginUnderTestMavenRepo"] =
        buildString {
            appendLine("repositories {")
            appendLine("  maven(\"${localMavenRepoForTestingPlugin.get().asFile.absoluteFile}\")")
            transitiveDeps.forEach { dependency ->
                dependency.moduleArtifacts.forEach { artifact ->
                    if (artifact.type == localMavenRepoType) {
                        appendLine("  maven(\"${artifact.file}\")")
                    }
                }
            }
            appendLine("}")
        }
    // this assumes that we are using the same version for all plugins (we set the version in the publishing config)
    // if the versions differ between artifacts, we would need to send each artifact version into the test.
    systemProperties["pluginUnderTestVersion"] = version
}

fun ResolvedDependency.allTransitiveDependencies(): Set<ResolvedDependency> {
    return buildSet {
        add(this@allTransitiveDependencies)
        addAll(children.flatMap { it.allTransitiveDependencies() })
    }
}

// incoming Configuration depends on the outgoing configs of all projects that we depend on
val incomingConfigurationForMavenReposForTesting: NamedDomainObjectProvider<Configuration> =
    configurations.register(incomingConfigurationNameForMavenReposForTesting) {
        withDependencies {
            fun DependencySet.addProjectDependencies(configuration: Configuration) {
                configuration.allDependencies.configureEach {
                    val dependency = this@configureEach
                    if (dependency is ProjectDependency) {
                        this@addProjectDependencies.add(
                            project.dependencies.project(
                                path = dependency.path,
                                configuration = outgoingConfigurationNameForMavenReposForTesting
                            )
                        )
                    }
                }
            }

            // any project that are added to `testImplementation` or its super configs will be used
            // `implementation` is a super config of `testImplementation`
            this.addProjectDependencies(configurations.getByName(TEST_IMPLEMENTATION_CONFIGURATION_NAME))
        }
    }

// outgoing extends from incoming and adds an artifact with a task dependency that force this project to publish its local repo.
val outgoingConfigurationForMavenReposForTesting: NamedDomainObjectProvider<Configuration> = configurations.register(
    outgoingConfigurationNameForMavenReposForTesting
) {
    // transitively publish the incoming repos as outgoing
    extendsFrom(incomingConfigurationForMavenReposForTesting.get())
}

artifacts {
    // publish the file path of our published local maven repo to other projects that depend on this one.
    add(outgoingConfigurationNameForMavenReposForTesting, localMavenRepoForTestingPlugin) {
        type = localMavenRepoType
        // tell gradle how to "build" the maven repo directory that will be exported as an artifact
        builtBy(tasks.named("publishAllPublicationsTo${mavenRepoName.uppercaseFirstChar()}Repository"))
    }
}
