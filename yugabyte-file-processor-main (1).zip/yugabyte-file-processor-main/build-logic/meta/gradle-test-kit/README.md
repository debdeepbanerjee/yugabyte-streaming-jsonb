`withPluginClasspath` isn't "realistic" and may have different behavior than the real build, and it can
cause surprising and hard to troubleshoot issues in your gradle test kit tests.

See an example of the issues you might run into here:
https://github.aexp.com/mbail1/gradle-reproducer-included-build-classpath-pollution

This plugin helps you avoid `withPluginClasspath` in Gradle Test Kit tests.

It provides similar functionality by publishing the plugin to the build directory and then includes it from a local file
based maven repo.

## Usage

First include the build in your settings.gradle.kts:
```kotlin
// this allows you to apply the "aexp.meta.gradle-test-kit" plugin
pluginManagement {
    includeBuild("../meta/gradle-test-kit")
}

// this allows you to use the test-fixtures which include the pluginUnderTestVersion() and pluginUnderTestMavenRepo() functions
includeBuild("../meta/gradle-test-kit")
```

Then apply the plugin in your build.gradle.kts:
```kotlin
plugins {
    id("aexp.meta.gradle-test-kit") // or apply id("aexp.meta.kotlin-dsl") which applies the gradle-test-kit transitively
}
```

Then call `pluginUnderTestVersion()` and `pluginUnderTestMavenRepo()` in your src/test/kotlin/.../MyPluginTest.kt file:
in your test like this (do NOT call `withPluginClasspath()`):
```kotlin
    @Test
    internal fun `test my-plugin`() {
        file("build.gradle.kts").writeText(
            """
            plugins {
               id("aexp.my-plugin") version("${pluginUnderTestVersion()}")
            }
            """.trimIndent()
        )

        writeSettingsFile()


    val buildResult = GradleRunner.create()
            .withDebug(true) // runs in process which is faster and allows you to attach a debugger.
            //.withPluginClasspath() // be sure to OMIT this
            .withProjectDir(tempDir)
            .withArguments("build")
            .buildAndFail()
    }
```

## Troubleshooting

If you see this error message, you are probably missing the `aexp.meta.gradle-test-kit` plugin in of your projects:

```
Project : declares a dependency from configuration 'incomingLocalMavenRepoForTesting' to configuration 'outgoingLocalMavenRepoForTesting' which is not declared in the descriptor for project
```
