plugins {
    `kotlin-dsl`
    `java-test-fixtures`
}

dependencies {
    implementation(embeddedKotlin("gradle-plugin"))
}

group = "build-logic-meta-gradle-test-kit"

// `apply(from =` should be avoided when possible and only used to solve circular logic issues
apply(from = "${rootDir}/../kotlin-jvm/src/main/kotlin/aexp/meta/kotlin-jvm-config.gradle.kts")
tasks.withType<org.jetbrains.kotlin.gradle.tasks.KotlinCompile>().configureEach {
    kotlinOptions {
        allWarningsAsErrors = false
    }
}