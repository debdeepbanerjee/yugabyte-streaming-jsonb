package aexp.meta

plugins {
    id("aexp.meta.kotlin-jvm")
    // 👇 equivalent of `kotlin-dsl`, work around for https://github.com/gradle/gradle/issues/22428
    id("org.gradle.kotlin.kotlin-dsl")
    id("aexp.meta.junit")
    id("aexp.meta.gradle-test-kit")
}
