import org.gradle.kotlin.dsl.support.expectedKotlinDslPluginsVersion

plugins {
    `kotlin-dsl`
}

dependencies {
    // work-around for https://github.com/gradle/gradle/issues/17825
    implementation(libs.kotlin.dsl.gradle.map { "${it.module}:$expectedKotlinDslPluginsVersion" })
    implementation(projects.kotlinJvm)
    implementation(projects.junit)
    implementation("build-logic-meta-gradle-test-kit:build-logic-meta-gradle-test-kit")
    testImplementation(testFixtures("build-logic-meta-gradle-test-kit:build-logic-meta-gradle-test-kit"))
}

// `apply(from =` should be avoided when possible and only used to solve circular logic issues
apply(from = "${rootDir}/kotlin-jvm/src/main/kotlin/aexp/meta/kotlin-jvm-config.gradle.kts")
