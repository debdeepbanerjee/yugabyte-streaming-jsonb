package aexp.meta

import aexp.dependenciesWithVersionCatalog

plugins {
    id("aexp.meta.kotlin-jvm")
}

dependenciesWithVersionCatalog {
    // have to use strings here because we are in the meta project, so we can't use the normal syntax sugar
    testImplementation(testFixtures(includedBuilds.buildLogic.testFixtures))
    testImplementation(libs.junit.jupiter.api)
    testImplementation(libs.assertK)
}

tasks.withType<Test>().configureEach {
    useJUnitPlatform()

    // this only affects tests in build-logic
    // to reduce the impact of https://github.com/gradle/gradle/issues/27588
    // we set it to 2 to make tests less flaky
    maxParallelForks = 2

    // copied from here:
    // https://github.com/gradle/gradle/issues/22765#issuecomment-1339427241
    // https://github.com/gradle/gradle/issues/22765#issuecomment-1444363323
    // Required to test configuration cache in tests when using withDebug(true)
    jvmArgs(
        "--add-opens",
        "java.base/java.util=ALL-UNNAMED",
        "--add-opens",
        "java.base/java.util.concurrent.atomic=ALL-UNNAMED",
        "--add-opens",
        "java.base/java.lang.invoke=ALL-UNNAMED",
        "--add-opens",
        "java.base/java.net=ALL-UNNAMED",
    )
}
