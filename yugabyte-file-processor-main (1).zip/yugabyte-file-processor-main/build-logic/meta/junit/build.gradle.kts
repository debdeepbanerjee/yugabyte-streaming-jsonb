plugins {
    `kotlin-dsl`
}

dependencies {
    implementation(projects.kotlinJvm)
    implementation(includedBuilds.buildLogic.settings.versionCatalog)
}


// `apply(from =` should be avoided when possible and only used to solve circular logic issues
apply(from = "${rootDir}/kotlin-jvm/src/main/kotlin/aexp/meta/kotlin-jvm-config.gradle.kts")
