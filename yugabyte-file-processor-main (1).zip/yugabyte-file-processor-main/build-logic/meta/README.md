## Meta plugins

This directory contains plugins that are applied to your build logic, not to your application code.

As an example,
the kotlin compiler task that compiles the kotlin this file:
`build-logic/dependency-locking/src/main/kotlin/aexp/dependency-locking.gradle.kts`
is configured by the "meta" plugin here:
`build-logic/meta/kotlin-dsl/src/main/kotlin/aexp/meta/kotlin-jvm.gradle.kts`
