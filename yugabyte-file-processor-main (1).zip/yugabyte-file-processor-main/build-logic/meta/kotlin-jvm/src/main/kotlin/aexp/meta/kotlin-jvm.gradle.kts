package aexp.meta

plugins {
    kotlin("jvm")
    id("aexp.meta.kotlin-jvm-config")
}
