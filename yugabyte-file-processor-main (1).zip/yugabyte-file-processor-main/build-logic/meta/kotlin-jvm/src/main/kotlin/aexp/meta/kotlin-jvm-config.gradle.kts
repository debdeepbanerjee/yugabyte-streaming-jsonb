package aexp.meta

import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import org.jetbrains.kotlin.gradle.plugin.getKotlinPluginVersion
import org.jetbrains.kotlin.gradle.tasks.KotlinJvmCompile

// this file is intended to be applied to with apply(from = "relative/path/to/this/kotlin-jvm-config.gradle.kts")
// Because this references the kotlin gradle plugin you will need to add it to the classpath of the build by adding this
// to the settings.gradle.kts where it is being used.
//
// plugins {
//    // enables use of apply(from... kotlin-jvm-config.gradle.kts)
//    kotlin("jvm") version(embeddedKotlinVersion) apply(false)
// }

// this file should only be applied to Gradle code, NOT the application Kotlin code in the project.
// we check that the versions match to avoid accidental classpath issues.
if (project.getKotlinPluginVersion() != embeddedKotlinVersion) {
    error("Must use $embeddedKotlinVersion (embeddedKotlinVersion), but found ${project.getKotlinPluginVersion()} (project.getKotlinPluginVersion()) ")
}

val libs: Provider<VersionCatalog> = provider { extensions.findByType<VersionCatalogsExtension>()?.named("libs") }
val jdkExecutionVersionForBuildLogic: Provider<Int> = libs.map { it.findVersion("jdk-execution-for-build-logic").get().requiredVersion.toInt() }
val jdkTargetVersionForBuildLogic: Provider<Int> =  libs.map { it.findVersion("jdk-target-for-build-logic").get().requiredVersion.toInt() }

// this file defines the kotlin/java configuration for build code (.gradle.kts files plus .kt files under /build-logic).
tasks.withType<KotlinJvmCompile>().configureEach {
    compilerOptions {
        allWarningsAsErrors.set(true)
        // Workaround for https://youtrack.jetbrains.com/issue/KT-61986
        jvmTarget.set(jdkTargetVersionForBuildLogic.map { JvmTarget.fromTarget(JavaVersion.toVersion(it).toString()) })
        // https://kotlinlang.org/docs/compiler-reference.html#xjdk-release-version
        freeCompilerArgs.add(jdkTargetVersionForBuildLogic.map { "-Xjdk-release=$it" })
    }
}

// The Gradle Java Plugin provides several tasks of type "JavaCompile".
// See: https://docs.gradle.org/current/userguide/java_plugin.html#sec:java_tasks
tasks.withType<JavaCompile>().configureEach {
    // Configure each task of type JavaCompile to compile source code with jdk 8.
    // "options.release.set(8)" will pass in "--release 8" as an argument to the JDK17 compiler,
    // which is defined in the below toolchain block. JavaCompile is a "toolchain aware" task.

    // Gradle runs kotlin scripts with targetJdk of 8, so set this to match to avoid warnings. This
    // is done to match the "kotlin-dsl" plugin.
    // See: https://docs.gradle.org/current/userguide/kotlin_dsl.html#sec:kotlin_compiler_arguments
    options.release.set(jdkTargetVersionForBuildLogic)
}

// Configuration block for the Gradle Java Plugin.
// See: https://docs.gradle.org/current/userguide/java_plugin.html
// The plugin adds compilation, testing and bundling capabilities to the "buildSrc" directory.
// Using `extensions.configure` instead of `java` accessor allows this to be use in an `apply(from =` context
extensions.configure<JavaPluginExtension> {
    // The toolchain block tells Gradle to build the project with JDK 17.
    // see: https://docs.gradle.org/current/userguide/toolchains.html
    toolchain {
        languageVersion.set(jdkExecutionVersionForBuildLogic.map(JavaLanguageVersion::of))
    }
}
