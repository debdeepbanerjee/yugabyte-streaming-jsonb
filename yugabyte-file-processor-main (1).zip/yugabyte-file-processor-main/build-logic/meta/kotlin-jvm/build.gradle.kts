plugins {
    `kotlin-dsl`
}

dependencies {
    implementation(embeddedKotlin("gradle-plugin"))
}

// `apply(from =` should be avoided when possible and only used to solve circular logic issues
apply(from = "${rootDir}/kotlin-jvm/src/main/kotlin/aexp/meta/kotlin-jvm-config.gradle.kts")
