plugins {
    id("aexp.meta.kotlin-dsl")
    id("aexp.meta.junit")
}

dependencies {
    implementation(projects.kotlinCore)
    implementation(includedBuilds.buildLogic.settings.versionCatalog)

    implementation(libs.test.retry.gradle)
}
