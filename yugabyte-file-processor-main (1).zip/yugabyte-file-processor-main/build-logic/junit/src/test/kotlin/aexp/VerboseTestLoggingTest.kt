package aexp

import aexp.meta.pluginUnderTestVersion
import aexp.test.fixtures.TempDirTest
import assertk.all
import assertk.assertThat
import assertk.assertions.contains
import assertk.assertions.matches
import org.gradle.testkit.runner.GradleRunner
import org.junit.jupiter.api.Test
import kotlin.text.RegexOption.DOT_MATCHES_ALL
import kotlin.text.RegexOption.MULTILINE

class VerboseTestLoggingTest : TempDirTest() {
    @Test
    internal fun `when a test failure is detected, a github error annotation is output to the console`() {
        writeSettingsFile()

        file("build.gradle.kts").writeText(
            // language=kotlin
            """
            import org.gradle.api.artifacts.dsl.LockMode.LENIENT

            plugins {
                id("aexp.junit") version("${pluginUnderTestVersion()}")
            }
            dependencyLocking {
                lockMode.set(LENIENT)
            }
            """.trimIndent()
        )

        file("src/test/kotlin/FailingTest.kt").writeText(
            // language=kotlin
            """
            import assertk.assertThat
            import assertk.assertions.isEqualTo
            import org.junit.jupiter.api.Test

            internal class FailingTest {
                @Test
                internal fun alwaysFail() {
                    assertThat(123).isEqualTo(456)
                }
            }
            """.trimIndent()
        )

        val build = GradleRunner.create()
            .withDebug(true) // runs in process which is faster and allows you to attach a debugger.
            .withProjectDir(tempDir)
            .withArguments("test", "--configuration-cache")
            .buildAndFail()

        assertThat(build.output).all {
            contains("FailingTest > alwaysFail")
            contains("expected:<[456]> but was:<[123]>")
            // github action workflow command'
            // https://docs.github.com/en/enterprise-server@3.1/actions/using-workflows/workflow-commands-for-github-actions#setting-an-error-message
            matches(
                Regex(
                    ".*^::error ((,?file=[^,]+)|(,?title=[^,]+)|(,?line=[^,]+)){3}.*::.+$.*",
                    setOf(DOT_MATCHES_ALL, MULTILINE)
                )
            )
        }
    }
}
