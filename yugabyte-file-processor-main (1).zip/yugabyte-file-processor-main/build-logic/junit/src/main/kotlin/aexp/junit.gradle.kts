package aexp

import org.gradle.api.tasks.testing.TestResult.ResultType.FAILURE
import org.gradle.api.tasks.testing.logging.TestExceptionFormat.FULL
import org.gradle.api.tasks.testing.logging.TestLogEvent.FAILED
import org.gradle.api.tasks.testing.logging.TestLogEvent.SKIPPED
import org.gradle.api.tasks.testing.logging.TestLogEvent.STARTED

plugins {
    jacoco
    id("org.gradle.test-retry")
    id("aexp.kotlin-core")
}

dependenciesWithVersionCatalog {
    testImplementation(libs.junit.jupiter.api)
    testRuntimeOnly(libs.junit.jupiter.engine)

    testImplementation(libs.assertK)
}

tasks.withType<Test>().configureEach {
    useJUnitPlatform()
    finalizedBy(tasks.jacocoTestReport)

    retry {
        maxRetries.set(1)
        failOnPassedAfterRetry.set(true)
    }

    // see https://docs.gradle.org/current/dsl/org.gradle.api.tasks.testing.logging.TestLoggingContainer.html
    testLogging {
        exceptionFormat = FULL
        events(SKIPPED, FAILED)
        debug {
            events(STARTED, SKIPPED, FAILED)
        }
    }

    // capture the project name during configuration, so that it will work with config cache.
    val projectName = project.name
    addTestListener(object : TestListener {
        override fun beforeSuite(suite: TestDescriptor?) = Unit
        override fun afterSuite(suite: TestDescriptor?, result: TestResult?) = Unit
        override fun beforeTest(testDescriptor: TestDescriptor?) = Unit

        override fun afterTest(testDescriptor: TestDescriptor?, result: TestResult?) {
            when (result?.resultType) {
                FAILURE -> {
                    result.exceptions.forEach { exception ->
                        logger.info(exception.stackTraceToString())

                        logger.quiet(
                            // ::error is a github actions workflow command
                            // https://docs.github.com/en/enterprise-server@3.1/actions/using-workflows/workflow-commands-for-github-actions#setting-an-error-message
                            // We add more info to the "message" to work around this issue:
                            // https://github.community/t/are-github-actions-notice-warning-error-annotations-broken/225674
                            "::error " +
                                    "file=${exception?.stackTrace?.firstOrNull()?.fileName}," +
                                    "title=${testDescriptor?.displayName}," +
                                    "line=${exception?.stackTrace?.firstOrNull()?.lineNumber}" +
                                    "::${projectName}:${testDescriptor?.className}:${testDescriptor?.displayName}%0A" +
                                    "Error: ${exception?.message}%0A" +
                                    "File: ${exception?.stackTrace?.firstOrNull()?.fileName}:${exception?.stackTrace?.firstOrNull()?.lineNumber}"
                        )
                    }
                }
                else -> {} // do nothing
            }
        }
    })
}

withVersionCatalog {
    jacoco {
        toolVersion = libs.versions.jacoco.get()
    }
}

tasks.jacocoTestReport {
    reports {
        xml.required.set(true)
    }
}
