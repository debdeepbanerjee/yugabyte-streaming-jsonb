# Build-Logic

The build-logic folder contains the various convention plugins which are used within the Gradle build.

Within `settings` is the where the repositories you wish to use should be defined.

Within `meta` are the configuration bits to build these conventions.

Within `conventions` are the conventions plugins used in this project.

## Library Versions

Within gradle the versions of libraries are handled within the `gradle/libs.versions.toml` file so that they apply 
across all of the modules.  This also allows them to work with depend-a-bot.

