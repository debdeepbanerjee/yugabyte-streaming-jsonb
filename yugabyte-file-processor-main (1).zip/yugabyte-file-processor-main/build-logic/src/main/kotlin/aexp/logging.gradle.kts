package aexp

import aexp.dependenciesWithVersionCatalog

plugins {
    id("aexp.kotlin-core")
}

dependenciesWithVersionCatalog {
    implementation(libs.bundles.kotlinSlf4jLog4j2)
}
