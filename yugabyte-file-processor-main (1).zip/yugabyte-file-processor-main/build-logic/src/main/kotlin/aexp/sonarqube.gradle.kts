package aexp

plugins {
    id("org.sonarqube")
}

sonarqube {
    properties {
        property("sonar.host.url", envVar("SONARQUBE_HOST_URL"))
        property("sonar.login", gradleProperty("aexp.sonar.login"))
    }
}

fun envVar(name: String) =
    providers.environmentVariable(name)
        .getForUseAtConfigurationTimeWithErrorMessage { "Environment variable '$name' not found" }
fun gradleProperty(name: String) =
    providers.gradleProperty(name)
        .getForUseAtConfigurationTimeWithErrorMessage { "Gradle property '$name' not found" }

fun <T> Provider<T>.getForUseAtConfigurationTimeWithErrorMessage(message: () -> String): T =
    orNull ?: throw IllegalArgumentException(message())
