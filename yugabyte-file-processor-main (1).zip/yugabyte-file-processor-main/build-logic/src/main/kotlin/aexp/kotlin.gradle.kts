package aexp

plugins {
    id("aexp.kotlin-core")
    id("aexp.junit")
    id("aexp.detekt")
    id("aexp.logging")
    id("aexp.sonarqube")
}
