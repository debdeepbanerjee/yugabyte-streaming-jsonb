package aexp

import aexp.dependenciesWithVersionCatalog

plugins {
    id("aexp.junit")
}

dependenciesWithVersionCatalog {
    testImplementation(project(":cpu-architecture"))
}

tasks.withType<Test>().configureEach {
    // can't name the property "os.arch", see https://github.com/gradle/gradle/issues/20916
    inputs.property("cpu-architecture", providers.systemProperty("os.arch"))
}
