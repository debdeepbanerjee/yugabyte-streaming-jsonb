package aexp

import aexp.dependenciesWithVersionCatalog

plugins {
    id("aexp.kotlin-core")
}

dependenciesWithVersionCatalog {
    testImplementation(libs.test.containers.core)
    testImplementation(libs.test.containers.junit)
}
