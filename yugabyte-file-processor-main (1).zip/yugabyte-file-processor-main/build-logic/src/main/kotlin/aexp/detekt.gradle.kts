package aexp

import aexp.dependenciesWithVersionCatalog

plugins {
    id("io.gitlab.arturbosch.detekt")
}

dependenciesWithVersionCatalog {
    detektPlugins(libs.detekt.formatting)
}

detekt {
    parallel = true
    buildUponDefaultConfig = true
    config.from(files(
        buildList {
            add(file("${rootProject.rootDir}/build-logic/detekt-config.yml"))
            file("$projectDir/detekt-config.yml").apply { if (exists()) add(this) }
        }
    ))
}
