package aexp

import aexp.meta.pluginUnderTestVersion
import aexp.test.fixtures.TempDirTest
import assertk.assertThat
import assertk.assertions.contains
import org.gradle.testkit.runner.GradleRunner
import org.junit.jupiter.api.Test

class FileExistsValueSourceTest : TempDirTest() {

    @Test
    internal fun `when detekt config file is deleted, then config cache is invalidated`() {
        writeSettingsFile()
        val configFileName = "detekt-config.yml"
        file(configFileName).writeText("some config")

        // detekt plugin calls .apply { if (exists()) add(this) } to see if the config file exists and add it conditionally
        file("build.gradle.kts").writeText(
            """
            import org.gradle.api.artifacts.dsl.LockMode.LENIENT

            plugins {
                id("aexp.detekt") version("${pluginUnderTestVersion()}")
            }
            dependencyLocking {
                lockMode.set(LENIENT)
            }
            """.trimIndent()
        )

        // can't use .withDebug(true) here because of https://github.com/gradle/gradle/issues/28006
        val build = GradleRunner.create()
            .withProjectDir(tempDir)
            .withArguments("detekt", "--configuration-cache", "-Dorg.gradle.kotlin.dsl.precompiled.accessors.strict=true")
            .build()

        assertThat(build.output).contains("Configuration cache entry stored.")

        // this should invalidate the config cache
        file(configFileName).delete()

        // can't use .withDebug(true) here because of https://github.com/gradle/gradle/issues/28006
        val build2 = GradleRunner.create()
            .withProjectDir(tempDir)
            .withArguments("detekt", "--stacktrace", "--configuration-cache", "-Dorg.gradle.kotlin.dsl.precompiled.accessors.strict=true")
            .build()

        // if we didn't use .apply { if (exists()) add(this) } then it would NOT invalidate the config cache
        assertThat(build2.output).contains("Calculating task graph as configuration cache cannot be reused because")
        assertThat(build2.output).contains("Configuration cache entry stored.")
    }
}
