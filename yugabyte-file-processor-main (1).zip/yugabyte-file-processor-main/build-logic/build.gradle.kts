plugins {
    id("aexp.meta.kotlin-dsl")
}

group = "root"

dependencies {
    implementation(includedBuilds.buildLogic.settings.versionCatalog)

    implementation(projects.kotlinCore)
    implementation(projects.junit)

    implementation(libs.detekt.gradle)
    implementation(libs.sonarqube.gradle)

    // for build-logic/src/test/kotlin
    testRuntimeOnly(libs.junit.jupiter.engine)
}
