package aexp

import org.gradle.api.JavaVersion
import org.gradle.api.Project
import org.gradle.api.artifacts.Dependency
import org.gradle.api.artifacts.dsl.DependencyHandler
import org.gradle.api.plugins.JavaPluginExtension
import org.gradle.api.provider.Provider
import org.gradle.api.tasks.compile.JavaCompile
import org.gradle.jvm.toolchain.JavaLanguageVersion
import org.gradle.kotlin.dsl.configure
import org.gradle.kotlin.dsl.withType
import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import org.jetbrains.kotlin.gradle.tasks.KotlinCompile

/**
 * We can't apply multiple kotlin plugins (jvm, android, js, etc) in one project, but we
 * can re-use configuration by extracting it to a separate subproject.
 */

// this file defines the kotlin/java configuration for your application/production code . i.e. everything outside build-logic/
val WithVersionCatalogs.jdkExecutionVersionForApplication: Provider<Int>
    get() = project.provider { project.libs.versions.jdk.execution.`for`.application.get().toInt() }
val WithVersionCatalogs.jdkTargetVersionForApplication: Provider<Int>
    get() = project.provider { project.libs.versions.jdk.target.`for`.application.get().toInt() }

fun Int.toJvmVersion(): JavaVersion = JavaVersion.toVersion(this)
fun Int.toJvmTarget() = JvmTarget.fromTarget(this.toJvmVersion().toString())

fun Project.configureKotlinPlugin() {
    addKotlinDependencies()
    configureKotlinCompilerOptions()
    configureJavaCompilerOptions()
    configureJvmToolchain()
}

fun Project.addKotlinDependencies() {
    plugins.withId("org.gradle.java-base") {
        dependenciesWithVersionCatalog {
            implementation(platform(libs.kotlin.bom))

            implementation(platform(libs.kotlinx.coroutines.bom))
            implementation(libs.kotlinx.coroutines.jdk9)
            implementation(libs.kotlinx.coroutines.core)

            testImplementation(libs.kotlinx.coroutines.test)
        }
    }
}

fun Project.configureKotlinCompilerOptions() {
    tasks.withType<KotlinCompile>().configureEach {
        compilerOptions {
            allWarningsAsErrors.set(
                providers
                    .gradleProperty("resy.kotlin.all.warnings.as.errors")
                    .toBoolean(valueIfNotPresent = true)
            )
            withVersionCatalog {
                jvmTarget.set(jdkTargetVersionForApplication.map { it.toJvmTarget() })
            }

            freeCompilerArgs.addAll(
                // https://kotlinlang.org/docs/compiler-reference.html#progressive
                "-progressive",
                "-opt-in=kotlin.ExperimentalStdlibApi",
                "-opt-in=kotlinx.coroutines.ExperimentalCoroutinesApi",
            )
        }
    }
}

fun Project.configureKotlinReflect() {
    tasks.withType<KotlinCompile>().configureEach {
        compilerOptions {
            freeCompilerArgs.addAll(
                "-opt-in=kotlin.reflect.jvm.ExperimentalReflectionOnLambdas",
            )
        }
    }

    dependenciesWithVersionCatalog {
        implementation(libs.kotlin.reflect)
    }
}


fun Project.configureJavaCompilerOptions() {
    // The Gradle Java Plugin provides several tasks of type "JavaCompile".
    // See: https://docs.gradle.org/current/userguide/java_plugin.html#sec:java_tasks
    tasks.withType<JavaCompile>().configureEach {
        // setting options.release doesn't work well with the Android Gradle Plugin (AGP)
        // AGP requires that we set sourceCompatibility and targetCompatibility instead
        withVersionCatalog {
            sourceCompatibility = jdkTargetVersionForApplication.get().toJvmVersion().toString()
            targetCompatibility = jdkTargetVersionForApplication.get().toJvmVersion().toString()
        }
    }
}

fun Project.configureJvmToolchain() {
    plugins.withId("org.gradle.java-base") {
        extensions.configure<JavaPluginExtension> {
            toolchain {
                // this tells gradle to execute toolchain aware tasks with this JDK
                // e.g. compileJava, compileKotlin, detekt, run
                withVersionCatalog {
                    languageVersion.set(jdkExecutionVersionForApplication.map(JavaLanguageVersion::of))
                }
            }
        }
    }
    plugins.withId("org.gradle.java") {
        extensions.configure<JavaPluginExtension> {
            withSourcesJar()
        }
    }
}


// Since we are not applying the kotlin or java plugin in this file these do not get generated.
// copied from generated accessors
fun DependencyHandler.testImplementation(dependencyNotation: Any): Dependency? =
    add("testImplementation", dependencyNotation)

fun DependencyHandler.implementation(dependencyNotation: Any): Dependency? =
    add("implementation", dependencyNotation)

//
fun Provider<String>.toBoolean(valueIfNotPresent: Boolean? = null): Provider<Boolean> =
        this.let {
            if(isPresent) {
                it
            } else {
                it.orElse(valueIfNotPresent?.toString() ?: error("value was missing and valueIfNotPresent was also null") )
            }
        }
       .map {
           it.toBooleanStrictOrNull()
               ?: error("expected \"true\" or \"false\", but was \"$it\"")
       }
