package aexp

plugins {
    kotlin("jvm")
}

configureKotlinPlugin()
