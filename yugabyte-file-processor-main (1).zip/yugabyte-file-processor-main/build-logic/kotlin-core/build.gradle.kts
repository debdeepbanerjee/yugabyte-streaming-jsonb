plugins {
    id("aexp.meta.kotlin-dsl")
}

dependencies {
    implementation(includedBuilds.buildLogic.settings.versionCatalog)

    // this is the version of kotlin used to compile your application code.
    // read from the version catalog (e.g. `libs.versions.toml`)
    implementation(libs.kotlin.gradle)
}
