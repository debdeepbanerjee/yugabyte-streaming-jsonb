plugins {
    jacoco
    id("aexp.meta.kotlin-dsl")
    id("aexp.meta.junit")
}

dependencies {
    implementation(projects.kotlinCore)
    implementation(includedBuilds.buildLogic.settings.versionCatalog)

    implementation(libs.test.retry.gradle)

    implementation(libs.bundles.spring.build)

    constraints {
        implementation(libs.jackson.bom) {
            because("Spring Boot plugin brings in an older, quarantined version of Jackson")
        }
        testImplementation(libs.xmlunit) {
            because("Spring Boot Starter Test brings in an older, quarantined version of xml-unit")
        }
    }

    testImplementation(libs.assertK)
}
