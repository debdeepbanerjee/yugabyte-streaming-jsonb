# Spring conventions.

This convention can be used to modify the transitive dependencies used by the Spring Framework.

Issues can arise where internal repositories quarantine a dependency. Conventions such as this allow these cases
to be circumvented.