package aexp

plugins {
    id("aexp.spring")
    id("org.springframework.boot")
    application
}

dependencies {
    implementation("org.springframework.boot:spring-boot-starter-actuator")
    implementation("com.gorylenko.gradle-git-properties:gradle-git-properties:2.4.2")
}

springBoot {
    buildInfo {
        properties {
            if (System.getProperty("git.branch") != null) {
                additional = mapOf(
                    "commit.id" to System.getProperty("git.commit.id", "none"),
                    "commit.url" to System.getProperty("git.commit.url", "none"),
                    "branch" to System.getProperty("git.branch", "none")
                )
            }
        }
    }
}
