package aexp

plugins {
    id("aexp.kotlin-core")
    kotlin("plugin.spring")
}

dependencies {
    implementation(platform(org.springframework.boot.gradle.plugin.SpringBootPlugin.BOM_COORDINATES))
    implementation("org.springframework.boot:spring-boot-starter")

    // test stuff
    testImplementation("org.springframework.boot:spring-boot-starter-test") {
        // spring-boot-starter-test brings in an older, quarantined version of xml-unit
        // bring this in explicitly if needed in the project
        exclude(group = "org.xmlunit", module = "xmlunit-core")
    }
}

tasks.getByName<Test>("test") {
    useJUnitPlatform()
}

tasks.withType<JavaCompile> {
    options.compilerArgs.add("-parameters")
}
