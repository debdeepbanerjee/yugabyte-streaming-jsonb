package aexp.test.fixtures

import aexp.meta.pluginUnderTestMavenRepo
import aexp.meta.pluginUnderTestVersion
import org.junit.jupiter.api.io.TempDir
import java.io.File
import java.nio.file.FileSystem
import java.nio.file.FileSystems
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.Paths
import kotlin.io.path.exists

open class TempDirTest {
    @TempDir
    lateinit var tempDir: File

    fun file(path: String): File = File(tempDir, path).also { assert(it.parentFile.mkdirs() || it.parentFile.exists()) }

    /**
     * checks to see if these exist and returns the first one that exists:
     * filePathToSearchFor
     * ../filePathToSearchFor
     * ../../filePathToSearchFor
     * ../../../filePathToSearchFor
     * and so on...
     */
    private fun Path.findClosestFileInAncestors(
        filePathToSearchFor: String,
        fileSystemProvider: () -> FileSystem = { FileSystems.getDefault() },
        createPath: (String) -> Path = { fileSystemProvider().getPath(it) },
    ): Path? {
        val startingDirectory = this
        require(Files.isDirectory(startingDirectory)) { "this (${startingDirectory.toRealPath()}) must be a directory" }
        val countOfPathComponents = this.toAbsolutePath().count()
        (0..countOfPathComponents).forEach { i ->
            createPath("${this.toAbsolutePath()}/${"../".repeat(i)}$filePathToSearchFor").let { pathInAncestor ->
                if (pathInAncestor.exists()) return pathInAncestor.toRealPath()
            }
        }
        return null
    }

    private fun findClosestFileInAncestors(
        filePathToSearchFor: String,
        fileSystemProvider: () -> FileSystem = { FileSystems.getDefault() },
        createPath: (String) -> Path = { fileSystemProvider().getPath(it) },
    ) =
        Paths.get(".").toAbsolutePath().findClosestFileInAncestors(filePathToSearchFor, fileSystemProvider, createPath)

    class PluginId(val id: String)
    fun id(id: String) = PluginId(id)

    fun writeSettingsFile(
        toDirectory: String = "",
        rootProjectName: String = this.javaClass.name.replace(Regex("[^a-zA-Z0-9\\-_]"), "_"),
        plugins: Iterable<PluginId> = listOf(),
        addVersionsCatalogsFromProject: Boolean = true,
        text: String = "",
    ) {
        val settingsDir = findClosestFileInAncestors("settings")
        file("${if(toDirectory.isEmpty() || toDirectory.endsWith("/")) toDirectory else "$toDirectory/" }settings.gradle.kts")
            .writeText(
                """
                rootProject.name = "$rootProjectName"

                pluginManagement {
                    includeBuild("$settingsDir")
                    apply(from = "$settingsDir/repositories/src/main/kotlin/aexp/repositories.settings.gradle.kts")
                    ${pluginUnderTestMavenRepo()}
                }

                plugins {
                    ${
                        plugins.joinToString("") { plugin ->
                            """
                               id("${plugin.id}") version("${pluginUnderTestVersion()}")
                            """.trimIndent()
                        }
                    }
                }
                ${
                    if (addVersionsCatalogsFromProject) {
                        """dependencyResolutionManagement {
                                versionCatalogs {
                                    register("libs") {
                                        from(files("${findClosestFileInAncestors("gradle/libs.versions.toml")}"))
                                    }
                                    register("includedBuilds") {
                                        from(files("${findClosestFileInAncestors("gradle/includedBuilds.versions.toml")}"))
                                    }
                                }
                        }""".trimIndent()
                    } else ""
                }

                $text
                """.trimIndent().also { println(it) }
        )
    }
}
