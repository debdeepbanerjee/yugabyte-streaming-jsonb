package aexp.test.fixtures.assertk

import assertk.Assert
import assertk.assertions.support.expected
import org.gradle.testkit.runner.BuildResult
import org.gradle.testkit.runner.BuildTask

fun Assert<BuildResult>.containsTask(expectedTask: BuildTask) = given { buildResult ->
    buildResult.tasks.find { actualTask ->
        actualTask.outcome == expectedTask.outcome && actualTask.path == expectedTask.path
    } ?: expected("to contain task $expectedTask, but task list was ${buildResult.tasks}")
}
