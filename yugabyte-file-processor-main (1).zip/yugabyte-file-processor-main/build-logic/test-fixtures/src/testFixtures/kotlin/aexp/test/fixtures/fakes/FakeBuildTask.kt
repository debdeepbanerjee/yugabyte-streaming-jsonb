package aexp.test.fixtures.fakes

import org.gradle.testkit.runner.BuildTask
import org.gradle.testkit.runner.TaskOutcome

data class FakeBuildTask(private val path: String, private val outcome: TaskOutcome) : BuildTask {
    override fun getPath() = path
    override fun getOutcome() = outcome
    override fun toString() = "$path=$outcome"
}
