plugins {
    kotlin("jvm")
    `java-test-fixtures`
}
// a bit awkward, but needed to be able to reference the root project of an included build.
group = "build-logic-test-fixtures"

dependencies {
    testFixturesApi(gradleTestKit())
    testFixturesApi(libs.assertK)
    testFixturesApi(libs.junit.jupiter.engine)

    testFixturesImplementation(testFixtures(includedBuilds.buildLogic.meta.subprojects.gradleTestKit))
}

// `apply(from =` should be avoided when possible and only used to solve circular logic issues
apply(from = "${rootDir}/../meta/kotlin-jvm/src/main/kotlin/aexp/meta/kotlin-jvm-config.gradle.kts")
