rootProject.name = "build-logic-test-fixtures"

pluginManagement {
    // In general, you should make every effort to avoid using `apply` and use `plugins {}` instead
    // in this case, it allows us to DRY our repositories and version-catalog setup and avoid a "bootstrap" problem.
    // if we can figure out a way to avoid `apply` here while DRY, we should do it
    apply(from = "../settings/repositories/src/main/kotlin/aexp/repositories.settings.gradle.kts")
    apply(from = "../settings/version-catalog/src/main/kotlin/aexp/version-catalog.settings.gradle.kts")
    includeBuild("../settings/develocity")
}

plugins {
    // adding this with apply(false) hoists it to the settings classloader.
    kotlin("jvm") version(embeddedKotlinVersion) apply(false)
    id("aexp.develocity")
}

includeBuild("../meta/gradle-test-kit")
