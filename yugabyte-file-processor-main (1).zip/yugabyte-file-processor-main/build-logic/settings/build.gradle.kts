plugins {
    // the base plugin adds the :check task
    base
}
