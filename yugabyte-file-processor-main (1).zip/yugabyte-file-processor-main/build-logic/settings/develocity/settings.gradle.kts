rootProject.name = "build-logic-settings-develocity"
enableFeaturePreview("TYPESAFE_PROJECT_ACCESSORS")

pluginManagement {
    // In general, you should make every effort to avoid using `apply` and use `plugins {}` instead
    // in this case, it allows us to DRY our repositories and version-catalog setup and avoid a "bootstrap" problem.
    // if we can figure out a way to avoid `apply` here while DRY, we should do it
    apply(from = "../repositories/src/main/kotlin/aexp/repositories.settings.gradle.kts")
    apply(from = "../version-catalog/src/main/kotlin/aexp/version-catalog.settings.gradle.kts")
}


plugins {
    // enables use of apply(from... kotlin-jvm-config.gradle.kts)
    kotlin("jvm") version(embeddedKotlinVersion) apply(false)
}
