package aexp

import com.gradle.develocity.agent.gradle.scan.BuildScanConfiguration
import java.text.DecimalFormat
import java.time.ZoneId
import kotlin.math.pow

plugins {
    id("com.gradle.develocity")
}

// This will set the username on the build scan to the GITHUB_ACTOR, which is "The name of the person or app that initiated the workflow."
environmentVariableOrNull("GITHUB_ACTOR")?.let { System.setProperty("user.name", it) }

val runningOnCi = environmentVariableOrNull("CI").toBoolean()
val runningOnCircleCi = environmentVariableOrNull("CIRCLECI")?.toBoolean() ?: false
val runningOnGitHubActions = environmentVariableOrNull("GITHUB_ACTIONS")?.toBoolean() ?: false
val runningOnGitHubDotCom = environmentVariableOrNull("GITHUB_SERVER_URL")?.startsWith("https://github.com") ?: false
val runningOnAmexGitHubEnterpriseServer =
    environmentVariableOrNull("GITHUB_SERVER_URL")?.startsWith("https://github.aexp.com") ?: false

val gradleEnterpriseServer =
    environmentVariableOrNull("GRADLE_ENTERPRISE_SERVER_DOMAIN")
        ?.let { "https://$it/" }
        ?: "https://gradle.aexp.com/"
// if you need access to https://gradle.aexp.com/, ask in #develocity slack channel
develocity {
    server = gradleEnterpriseServer
    buildScan.publishing.onlyIf { true }

    with(buildScan) {
        addValueFromSystemProperty("os.arch")
        addValueFromSystemProperty("os.name")
        addValueFromSystemProperty("user.country")
        addValueFromSystemProperty("java.specification.version")
        value("cores", cores())
        value("systemRam", systemRam())
        value("timezone", timezone())
        // Please don't remove this, it helps us identify projects on the JVM Paved Road
        value("repository.template", "amex-eng/jvm-paved-road-template")
    }

    if (runningOnCi && runningOnGitHubActions) {
        val githubServerUrl = environmentVariable("GITHUB_SERVER_URL")
        val githubRepository = environmentVariable("GITHUB_REPOSITORY")
        val githubRunId = environmentVariable("GITHUB_RUN_ID")
        val githubSha = environmentVariable("GITHUB_SHA")
        with(buildScan) {
            tag("CI")
            tag("GENERATED_BY_SPRING_INITIALIZER")
            value("GITHUB_SERVER_URL", githubServerUrl)
            value("GITHUB_REPOSITORY", githubRepository)
            addValueFromEnvironmentVariable("GITHUB_WORKFLOW")
            addValueFromEnvironmentVariable("RUNNER_NAME")
            value(
                "branch",
                environmentVariableOrNull("GITHUB_HEAD_REF")?.ifBlank { null } // PR builds
                    ?: environmentVariable("GITHUB_REF").substringAfter("refs/heads/") // non-PR builds
            )
            link("CI Build", "$githubServerUrl/$githubRepository/actions/runs/$githubRunId")
            link("Git Commit", "$githubServerUrl/$githubRepository/commit/$githubSha")
        }
        environmentVariableOrNull("GITHUB_REF")?.let { githubRef ->
            val indexOfPrNumber = 2
            val prNumber = githubRef.split("/")[indexOfPrNumber] // githubRef looks like "refs/pull/44/merge"
            if (prNumber.matches(Regex("^\\d+$"))) {
                buildScan.link("Pull Request", "$githubServerUrl/$githubRepository/pull/$prNumber")
            }
        }
    } else {
        buildScan.tag("GENERATED_BY_SPRING_INITIALIZER")
        buildScan.tag("LOCAL")
    }
}

buildCache {
    remote(HttpBuildCache::class.java) {
        url = uri("${gradleEnterpriseServer}cache/")
        isEnabled = !runningOnCircleCi && !runningOnGitHubDotCom
        isPush = runningOnCi && runningOnAmexGitHubEnterpriseServer
    }
}

enableFeaturePreview("TYPESAFE_PROJECT_ACCESSORS")

fun Settings.environmentVariableOrNull(name: String) = this.providers.environmentVariable(name).orNull

fun Settings.environmentVariable(name: String) =
    environmentVariableOrNull(name) ?: throw IllegalStateException("No environment variable named '$name' was found")

fun Settings.systemPropertyOrNull(name: String) = this.providers.systemProperty(name).orNull

fun Settings.systemProperty(name: String) =
    systemPropertyOrNull(name) ?: throw IllegalStateException("No system property named '$name' was found")

fun BuildScanConfiguration.addValueFromSystemProperty(name: String) =
    systemPropertyOrNull(name)?.let { value ->
        value(name, value)
    }

fun BuildScanConfiguration.addValueFromEnvironmentVariable(name: String) =
    environmentVariableOrNull(name)?.let { value ->
        value(name, value)
    }

fun systemRam(): String {
    @Suppress("DEPRECATION") // totalPhysicalMemorySize is needed to support JDK older than 14
    val ramInBytes =
        (java.lang.management.ManagementFactory.getOperatingSystemMXBean() as? com.sun.management.OperatingSystemMXBean)?.totalPhysicalMemorySize
    return if (ramInBytes != null) {
        "${ramInBytes.bytesToGibibytes().formatWithUpToOneDecimal()} GiB"
    } else "UNKNOWN"
}

fun Long.bytesToGibibytes() = this / (1024.0.pow(3))
fun Double.formatWithUpToOneDecimal() = DecimalFormat("0.#").format(this)

fun timezone() = ZoneId.systemDefault().id
fun cores() = Runtime.getRuntime().availableProcessors().toString()
