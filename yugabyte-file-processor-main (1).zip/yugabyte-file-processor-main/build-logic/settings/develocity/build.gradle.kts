plugins {
    `kotlin-dsl`
}

dependencies {
    implementation(libs.develocity.gradle.plugin)
}

// `apply(from =` should be avoided when possible and only used to solve circular logic issues
apply(from = "${rootDir}/../../meta/kotlin-jvm/src/main/kotlin/aexp/meta/kotlin-jvm-config.gradle.kts")
