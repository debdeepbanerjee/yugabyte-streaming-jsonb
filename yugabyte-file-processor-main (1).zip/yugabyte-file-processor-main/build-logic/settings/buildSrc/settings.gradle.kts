rootProject.name = "build-logic-settings-buildSrc"
pluginManagement {
    // work-around https://github.com/gradle/gradle/issues/23633
    // ideally buildSrc should be avoided.
    // `apply(from =` should be avoided when possible and only used to solve circular logic issues
    apply(from = "../repositories/src/main/kotlin/aexp/repositories.settings.gradle.kts")
    includeBuild("../develocity")
}

plugins {
    id("aexp.develocity")
}
