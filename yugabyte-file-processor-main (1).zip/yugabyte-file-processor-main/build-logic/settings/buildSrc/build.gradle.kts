plugins {
    // required to create the `implementation` configuration we use in the dependencies block below when running as a stand-alone build
    kotlin("jvm") version(embeddedKotlinVersion)
}

// work-around https://github.com/gradle/gradle/issues/23633
// enables use of apply(from... kotlin-jvm-config.gradle.kts)
// ideally buildSrc directory should be avoided altogether and instead we would use this in settings.gradle.kts in the parent directory
// plugins {
//    // enables use of apply(from... kotlin-jvm-config.gradle.kts)
//    kotlin("jvm") version(embeddedKotlinVersion) apply(false)
// }
// but the below config has the equivalent effect
// this works because buildSrc inserts a classpath in the the heirarchy when `apply(from =` is resolved
dependencies {
    implementation(embeddedKotlin("gradle-plugin"))
}
