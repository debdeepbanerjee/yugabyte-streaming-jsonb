import kotlin.io.path.toPath

plugins {
    `kotlin-dsl`
    id("aexp.meta.gradle-test-kit")
}
group = name

dependencies {
    // This workaround was suggested here: https://github.com/gradle/gradle/issues/15383#issuecomment-779893192
    api(files(libs.javaClass.protectionDomain.codeSource.location.toURI().toPath()))
    api(files(includedBuilds.javaClass.protectionDomain.codeSource.location.toURI().toPath()))

    testImplementation(libs.assertK)
    testImplementation(libs.junit.jupiter.engine)
    testImplementation(libs.jimfs)

    testImplementation(testFixtures(includedBuilds.buildLogic.testFixtures))
}

tasks.withType<Test>().configureEach {
    useJUnitPlatform()
}

// `apply(from =` should be avoided when possible and only used to solve circular logic issues
apply(from = "${rootDir}/../../meta/kotlin-jvm/src/main/kotlin/aexp/meta/kotlin-jvm-config.gradle.kts")
