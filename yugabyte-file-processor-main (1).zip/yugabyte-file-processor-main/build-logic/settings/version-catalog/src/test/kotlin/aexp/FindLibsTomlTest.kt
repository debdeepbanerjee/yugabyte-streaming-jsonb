package aexp

import aexp.Version_catalog_settings_gradle.VersionCatalog
import assertk.assertFailure
import assertk.assertThat
import assertk.assertions.isEqualTo
import assertk.assertions.messageContains
import com.google.common.jimfs.Configuration
import com.google.common.jimfs.Jimfs
import org.junit.jupiter.api.Test
import java.io.IOException
import java.nio.charset.Charset
import java.nio.file.Files
import java.nio.file.OpenOption
import java.nio.file.Path
import java.nio.file.attribute.FileAttribute

class FindLibsTomlTest {
    @Test
    fun `findClosestFileInAncestors finds toml 3 directories up`() {
        val workingDir = "/Users/me/"
        val fakeFileSystem = Jimfs.newFileSystem(
            Configuration.unix().toBuilder()
                .setWorkingDirectory(workingDir)
                .build()
        ).also {
            it.getPath("${workingDir}gradle/")
                .createDirectories()
                .resolve("libs.versions.toml")
                .writeText(
                    // language=toml
                    """
                [versions]
                junit = "5.9.0"
                """.trimIndent()
                )
            it.getPath("${workingDir}foo/bar/baz/")
                .createDirectories()
                .resolve("settings.gradle.kts")
                .writeText(
                    """
                rootProject.name = "foo"
                """.trimIndent()
                )
        }

        with(VersionCatalog) {
            assertThat(
                fakeFileSystem.getPath("foo/bar/baz/")
                    .findClosestFileInAncestors(
                        "gradle/libs.versions.toml",
                        fileSystemProvider = { fakeFileSystem }
                    )
            ).isEqualTo(fakeFileSystem.getPath("/Users/me/gradle/libs.versions.toml"))
        }
    }

    @Test
    fun `findClosestFileInAncestors finds toml is same directory`() {
        val workingDir = "/Users/me/"
        val fakeFileSystem = Jimfs.newFileSystem(
            Configuration.unix().toBuilder()
                .setWorkingDirectory(workingDir)
                .build()
        ).also {
            it.getPath("${workingDir}gradle/")
                .createDirectories()
                .resolve("libs.versions.toml")
                .writeText(
                    // language=toml
                    """
                [versions]
                junit = "5.9.0"
                """.trimIndent()
                )
            it.getPath(workingDir)
                .createDirectories()
                .resolve("settings.gradle.kts")
                .writeText(
                    """
                rootProject.name = "foo"
                """.trimIndent()
                )
        }

        with(VersionCatalog) {
            assertThat(
                fakeFileSystem.getPath("")
                    .findClosestFileInAncestors(
                        "gradle/libs.versions.toml",
                        fileSystemProvider = { fakeFileSystem }
                    )
            ).isEqualTo(fakeFileSystem.getPath("/Users/me/gradle/libs.versions.toml"))
        }
    }

    @Test
    fun `findClosestFileInAncestors fails if this is not a directory`() {
        val workingDir = "/Users/me/"
        val fakeFileSystem = Jimfs.newFileSystem(
            Configuration.unix().toBuilder()
                .setWorkingDirectory(workingDir)
                .build()
        ).also {
            it.getPath("${workingDir}gradle/")
                .createDirectories()
                .resolve("libs.versions.toml")
                .writeText(
                    // language=toml
                    """
                [versions]
                junit = "5.9.0"
                """.trimIndent()
                )
            it.getPath(workingDir)
                .createDirectories()
                .resolve("settings.gradle.kts")
                .writeText(
                    """
                rootProject.name = "foo"
                """.trimIndent()
                )
        }

        with(VersionCatalog) {
            assertFailure {
                fakeFileSystem.getPath("settings.gradle.kts")
                    .findClosestFileInAncestors(
                        "gradle/libs.versions.toml",
                        fileSystemProvider = { fakeFileSystem }
                    )
            }.messageContains("must be a directory")
        }
    }

}

// from https://github.com/JetBrains/kotlin/blob/v1.7.20/libraries/stdlib/jdk7/src/kotlin/io/path/PathUtils.kt
// the below can be removed in a future version of gradle with Kotlin Language version >= 1.5
// https://docs.gradle.org/current/userguide/compatibility.html#kotlin
@Throws(IOException::class)
fun Path.writeText(text: CharSequence, charset: Charset = Charsets.UTF_8, vararg options: OpenOption) {
    Files.newOutputStream(this, *options).writer(charset).use { it.append(text) }
}

fun Path.createDirectories(vararg attributes: FileAttribute<*>): Path =
    Files.createDirectories(this, *attributes)
