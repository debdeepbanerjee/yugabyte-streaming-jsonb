package aexp

import aexp.test.fixtures.TempDirTest
import assertk.assertThat
import assertk.assertions.contains
import org.gradle.testkit.runner.GradleRunner
import org.junit.jupiter.api.Test

class VersionCatalogTest : TempDirTest() {
    @Test
    internal fun `test that we can find the toml file in an ancestor directory`() {
        writeSettingsFile(
            toDirectory = "foo/bar/baz",
            rootProjectName = "locking-test",
            plugins = listOf(id("aexp.version-catalog")),
            // the point of this test is to find local versions catalogs,
            // so we need to define them in this test and not use catalog from the project
            addVersionsCatalogsFromProject = false,
        )

        file("gradle/includedBuilds.versions.toml").writeText(
            // language=toml
            """
            [libraries]

            ## we list our subproject of included builds here as a way to get Gradle to create accessors for us.
            buildLogic-settings-subprojects-versionCatalogs = { module = "build-logic-settings:version-catalog" }
            buildLogic-settings-subprojects-testFixtures = { module = "build-logic-settings:test-fixtures" }
            """.trimIndent()
        )

        file("gradle/libs.versions.toml").writeText(
            // language=toml
            """
            [versions]
            junit = "5.9.0"
            assertK = "0.25"

            [libraries]
            junit-jupiter-engine = { module = "org.junit.jupiter:junit-jupiter-engine", version.ref = "junit" }
            assertK = { module = "com.willowtreeapps.assertk:assertk-jvm", version.ref = "assertK" }
            """.trimIndent()
        )

        file("foo/bar/baz/build.gradle.kts").writeText(
            """
            plugins {
               kotlin("jvm") version("1.7.10")
            }

            dependencies {
                testImplementation(libs.assertK)
                testImplementation(libs.junit.jupiter.engine)
            }

            println("assertK version: " + libs.assertK.get().versionConstraint.requiredVersion)
            """.trimIndent()
        )

        val buildResult = GradleRunner.create()
            .withDebug(true) // runs in process which is faster and allows you to attach a debugger.
            .withProjectDir(tempDir.resolve("foo/bar/baz"))
            .withArguments("build")
            .build()

        assertThat(buildResult.output).contains("assertK version: 0.25")
    }
}
