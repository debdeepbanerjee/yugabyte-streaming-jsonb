package aexp

import aexp.Version_catalog_settings_gradle.VersionCatalog.findClosestFileInAncestors
import java.nio.file.FileSystem
import java.nio.file.FileSystems
import java.nio.file.Files
import java.nio.file.Path

// wrapping this in `object` allows this to work in a unit test and with apply(from= )
object VersionCatalog {

    /**
     * checks to see if these exist and returns the first one that exists:
     * filePathToSearchFor
     * ../filePathToSearchFor
     * ../../filePathToSearchFor
     * ../../../filePathToSearchFor
     * and so on...
     */
    fun Path.findClosestFileInAncestors(
        filePathToSearchFor: String,
        fileSystemProvider: () -> FileSystem = { FileSystems.getDefault() },
        createPath: (String) -> Path = { fileSystemProvider().getPath(it) },
    ): Path {
        val startingDirectory = this
        require(Files.isDirectory(startingDirectory)) { "this (${startingDirectory.toRealPath()}) must be a directory" }
        val countOfPathComponents = this.toAbsolutePath().count()
        (0..countOfPathComponents).forEach { i ->
            createPath("${this.toAbsolutePath()}/${"../".repeat(i)}$filePathToSearchFor").let { pathInAncestor ->
                if (pathInAncestor.exists()) return pathInAncestor.toRealPath()
            }
        }
        throw java.io.FileNotFoundException("Could not find $filePathToSearchFor in any parent of ${this.toRealPath()}")
    }

    private fun Path.exists() = Files.exists(this)

}

dependencyResolutionManagement {
    @Suppress("UnstableApiUsage") // acknowledged, willing to adjust if needed after it goes stable
    versionCatalogs {
        create("libs") {
            from(files(file("$settingsDir").toPath().findClosestFileInAncestors(
                "gradle/libs.versions.toml",
                createPath = { file(it).toPath() },
            )))
        }
        create("includedBuilds") {
            from(files(file("$settingsDir").toPath().findClosestFileInAncestors(
                "gradle/includedBuilds.versions.toml",
                createPath = { file(it).toPath() },
            )))
        }
    }
}
