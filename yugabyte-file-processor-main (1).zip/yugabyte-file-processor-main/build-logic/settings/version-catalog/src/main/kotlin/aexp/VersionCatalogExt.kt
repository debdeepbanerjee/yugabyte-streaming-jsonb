package aexp

import org.gradle.accessors.dm.LibrariesForIncludedBuilds
import org.gradle.accessors.dm.LibrariesForLibs
import org.gradle.api.Project
import org.gradle.api.artifacts.Configuration
import org.gradle.api.artifacts.dsl.DependencyHandler
import org.gradle.kotlin.dsl.dependencies

// 🚨 this whole file is one big work around for https://github.com/gradle/gradle/issues/15383
// This will be run during precompiled script accessor generation where the version catalog accessors will not exist

/**
 * If you want to use `libs` accessors in precompiled script plugins,
 * use `dependenciesWithVersionCatalog { ... }` instead of `dependencies { ... }`
 */
fun Project.dependenciesWithVersionCatalog(block: DependencyHandlerScopeWithVersionCatalogs.() -> Unit ) {
    if(versionCatalogAccessorsForLibsExist()) {
        dependencies {
            DependencyHandlerScopeWithVersionCatalogs(this, this@dependenciesWithVersionCatalog).block()
        }
    } else {
        // isGradleKotlinDslAccessors() should never be false here, but we want a useful error message in the case that it is false
        // "test" project is for ProjectBuilder tests
        require(isGradleKotlinDslAccessors() || name == "test") { "version catalog accessors did not exist on project: ${this.project.name}" }
    }
}

/**
 * If you want to use `libs` accessors in precompiled script plugins outside of a `dependencies { ... }` block,
 * use `withVersionCatalog { ... }`
 */
fun Project.withVersionCatalog(block: WithVersionCatalogs.() -> Unit) {
    if (versionCatalogAccessorsForLibsExist()) {
        RealWithVersionCatalogs(this).block()
    } else {
        // isGradleKotlinDslAccessors() should never be false here, but we want a useful error message in the case that it is false
        // "test" project is for ProjectBuilder tests
        require(isGradleKotlinDslAccessors() || name == "test") { "version catalog accessors did not exist on project: ${this.project.name}" }
    }
}

interface WithVersionCatalogs {
    val project: Project
    val Project.libs: LibrariesForLibs
        get() {
            checkThatProjectMatchesThis()
            return librariesForLibs ?: error("could not retrieve 'libs' version catalog on project: ${this@WithVersionCatalogs.project.name}")
        }


    val Project.includedBuilds: LibrariesForIncludedBuilds
        get() {
            checkThatProjectMatchesThis()
            return librariesForIncludedBuilds ?: error("could not retrieve 'includedBuilds' version catalog on project: ${this@WithVersionCatalogs.project.name}")
        }

    fun Project.checkThatProjectMatchesThis() {
        check(this == project) {
            """
               Projects must be the same:
               this: ${this}@${System.identityHashCode(this)}
               project: ${project}@${System.identityHashCode(project)}
            """.trimIndent()
        }
    }
}

class DependencyHandlerScopeWithVersionCatalogs(
    private val delegateDependencyHandler: DependencyHandler,
    override val project: Project
): WithVersionCatalogs, DependencyHandler by delegateDependencyHandler {
    // mirrors the API of DependencyHandlerScope
    operator fun Configuration.invoke(dependency: Any) = add(this@invoke.name, dependency)
}

private class RealWithVersionCatalogs(override val project: Project) : WithVersionCatalogs

private val Project.librariesForLibs: LibrariesForLibs?
    get() = (this as org.gradle.api.plugins.ExtensionAware).extensions.findByName("libs") as? LibrariesForLibs

private val Project.librariesForIncludedBuilds: LibrariesForIncludedBuilds?
    get() = (this as org.gradle.api.plugins.ExtensionAware).extensions.findByName("includedBuilds") as? LibrariesForIncludedBuilds

private fun Project.versionCatalogAccessorsForLibsExist() = librariesForLibs != null

// workaround from https://github.com/gradle/gradle/issues/22468#issuecomment-1286530610
private fun Project.isGradleKotlinDslAccessors() = name == "gradle-kotlin-dsl-accessors"
