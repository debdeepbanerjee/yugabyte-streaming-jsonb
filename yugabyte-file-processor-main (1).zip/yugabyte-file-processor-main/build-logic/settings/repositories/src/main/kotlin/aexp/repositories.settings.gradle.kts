package aexp

import org.gradle.api.initialization.resolve.RepositoriesMode.FAIL_ON_PROJECT_REPOS
import org.gradle.api.initialization.resolve.RepositoriesMode.PREFER_SETTINGS

fun InclusiveRepositoryContentDescriptor.includeGroupByPrefix(groupPrefix: String) {
    includeGroupByRegex("^${groupPrefix.replace(".", "\\.")}(?:\\..+|\\Z)")
}

fun RepositoryHandler.configureRepositories() {

    // use this to explicitly specify a version you wish to pull from local m2.  Remember not to check it in
//    exclusiveContent {
//        forRepository { mavenLocal() }
//        filter {
//            // includeVersion(String group, String moduleName, String version)
//        }
//    }

    exclusiveContent {
        forRepository { maven("https://artifactory.aexp.com/corporate/") }
        filter {
            // this needs to be more specific to your dependencies
            includeGroupByPrefix("com.aexp")
            includeGroupByPrefix("com.americanexpress")
        }
    }

    exclusiveContent {
        forRepository { maven("https://artifactory.aexp.com/iq-gradle/") }
        filter {
            includeGroup("com.gorylenko.gradle-git-properties")
            includeGroup("com.github.jacobono")
            includeGroupByPrefix("net.ltgt")
            includeGroupByPrefix("com.gradle")
            includeGroupByPrefix("org.gradle")
            includeModule("org.sonarsource.scanner.gradle", "sonarqube-gradle-plugin")

        }
    }



    exclusiveContent {
        forRepository { maven("https://artifactory.aexp.com/third-party/") }
        filter {
            includeGroupByPrefix("com.voltage")
            includeGroupByPrefix("com.whitecryption")
        }
    }

    exclusiveContent {
        forRepository { maven("https://artifactory.aexp.com/third-party-collabnet/") }
        filter {
            includeGroupByPrefix("com.aexp.sec.util")
            includeGroup("com.ancientprogramming.fixedformat4j")
            includeGroup("com.cyberark.sdk")
        }
    }

    exclusiveContent {
        forRepository { maven("https://artifactory.aexp.com/corporate-collabnet/") }
        filter {
            includeModule("com.aexp.sec.crypto", "libloader")
        }
    }



    exclusiveContent {
        forRepository { maven("https://artifactory.aexp.com/iq-maven-onehippo-proxy/") }
        filter {
            includeModule("javax.annotation", "jsr305")
        }
    }

    // Anything which can't be found above, get from here.  This saves having huge include lists
    maven("https://artifactory.aexp.com/iq-maven-central-proxy/")
}

settings.pluginManagement.repositories.configureRepositories()
settings.dependencyResolutionManagement.repositories.configureRepositories()
//TODO set to PREFER_SETTINGS instead of FAIL_ON_PROJECT_REPOS to fix below error
//Build was configured to prefer settings repositories over project repositories
// but repository 'maven3' was added by plugin class 'JetGradlePlugin'
settings.dependencyResolutionManagement.repositoriesMode.set(FAIL_ON_PROJECT_REPOS)
