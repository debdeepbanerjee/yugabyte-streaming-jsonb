rootProject.name = "build-logic"


pluginManagement {
    // In general, you should make every effort to avoid using `apply` and use `plugins {}` instead
    // in this case, it allows us to DRY our repositories setup and avoid a "bootstrap" problem.
    // if we can figure out a way to avoid `apply` here while DRY, we should do it
    apply(from = "settings/repositories/src/main/kotlin/aexp/repositories.settings.gradle.kts")
    includeBuild("settings/develocity")
    includeBuild("settings/version-catalog")
    includeBuild("settings")
    includeBuild("meta")
}

plugins {
    id("aexp.version-catalog")
    id("aexp.develocity")
}

enableFeaturePreview("TYPESAFE_PROJECT_ACCESSORS")

includeBuild("meta/gradle-test-kit")
includeBuild("settings/version-catalog")
includeBuild("meta")
include("kotlin-core")
include("junit")
include("spring")
include("conventions")