package aexp

plugins {
    id("aexp.spring")
    id("aexp.spring-kotlin")
    id("aexp.jacoco")
    id("aexp.spotless")
    id("jvm-test-suite")
    id("jacoco-report-aggregation")

}