package aexp

import aexp.withVersionCatalog


plugins {
    id("aexp.kotlin-core")
    id("com.diffplug.spotless")

}

withVersionCatalog {

    spotless {
        java {
            importOrder()
            removeUnusedImports()
            googleJavaFormat(libs.versions.googleJavaFormat.get())
            trimTrailingWhitespace()
            endWithNewline()
        }
    }
}


tasks.named("spotlessApply") {
    doLast {
        println("Spotless applied successfully.")
    }
}