package aexp

import aexp.JacocoConfiguration
import aexp.withVersionCatalog
import org.gradle.internal.impldep.org.junit.experimental.categories.Categories.CategoryFilter.exclude

plugins {
    jacoco
    id("aexp.kotlin-core")
    id("aexp.junit")
}

val jacocoConfiguration = extensions.create<JacocoConfiguration>(JacocoConfiguration.extensionDslName)

tasks.jacocoTestCoverageVerification {
    dependsOn(tasks.jacocoTestReport)
    exclude(jacocoConfiguration.excludes)
    violationRules {
        rule {
            element = "BUNDLE"
            limit {
                counter = "BRANCH"
                minimum = jacocoConfiguration.branchMinimum.get()
            }
        }
        rule {
            element = "BUNDLE"
            limit {
                counter = "LINE"
                minimum = jacocoConfiguration.lineMinimum.get()
            }
        }
    }
}

tasks.build {
    finalizedBy(tasks.getByName("jacocoTestCoverageVerification"))
}

fun JacocoCoverageVerification.exclude(globsToExclude: ListProperty<String>) {
    classDirectories.setFrom(sourceSets.main.map { mainSourceSet ->
        globsToExclude.flatMap { pathsToExclude ->
            project.provider {
                mainSourceSet.output.classesDirs.map { classDir ->
                    project.fileTree(classDir) {
                        exclude(pathsToExclude)
                    }
                }
            }
        }
    })
}