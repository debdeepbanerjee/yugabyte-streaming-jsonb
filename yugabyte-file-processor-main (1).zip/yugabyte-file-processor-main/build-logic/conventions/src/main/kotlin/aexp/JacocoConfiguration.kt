package aexp

import org.gradle.api.model.ObjectFactory
import java.math.BigDecimal

open class JacocoConfiguration(objects: ObjectFactory) {
    val excludes = objects.listProperty<String>().convention(emptyList())

    // minimum values needs to be expressed as a string between 0.0 and 1.0 for 0 to 100%
    val branchMinimum = objects.property<BigDecimal>().convention("0.0".toBigDecimal())
    val lineMinimum = objects.property<BigDecimal>().convention("0.0".toBigDecimal())

    companion object {
        const val extensionDslName = "jacocoConfiguration"
    }
}

inline fun <reified T> ObjectFactory.listProperty() = this.listProperty(T::class.java)
inline fun <reified T> ObjectFactory.property() = this.property(T::class.java)
