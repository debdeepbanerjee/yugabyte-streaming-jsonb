plugins {
    jacoco
    id("aexp.meta.kotlin-dsl")
    id("aexp.meta.junit")

}

dependencies {
    implementation(libs.spotless.gradle)
    implementation(projects.kotlinCore)
    implementation(includedBuilds.buildLogic.settings.versionCatalog)
    implementation(projects.junit)
    implementation(projects.spring)
    implementation(libs.test.retry.gradle)
    implementation(libs.bundles.spring.build)
    testImplementation(libs.assertK)


}
