package com.example.beanio;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * Enhanced file trailer with additional statistics
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EnhancedFileTrailer {
    private String recordType;
    private Long totalRecords;
    private BigDecimal totalAmount;
    private Double averageRiskScore;
    private Long uniqueCustomers;
}
